
 // imports de javafx para que se muestre y funcione todo
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Ejercicio PROG10_Tarea_ejercicio1
 * @author adrian ferreira araujo
 * @date 12/04/2026
 */

public class Main extends Application {
    // Componentes de la interfaz
    // Y variables de estado para la lógica de cálculo
    // es una calculadora de uso por pantalla, no funciona el teclado para evitar que el user ponga
    // cualquier cosa
    private TextField pantalla;
    private Label historial; // el historial
    private long num1 = 0; // Almacena el primer operando o el resultado parcial
    private String operador = ""; // Almacena la operación pendiente
    private boolean inicio = true;  // Indica si el siguiente dígito debe limpiar la pantalla

    @Override
    public void start(Stage primaryStage) {
        // Elementos visuales
        // --- CONFIGURACIÓN DE LA PANTALLA ---
        historial = new Label(""); // Arriba, pequeñito
        historial.setStyle("-fx-font-size: 14px; -fx-text-fill: gray;");

        pantalla = new TextField("0");
        pantalla.setEditable(false); // Evitamos entrada por teclado físico para integridad de datos
        pantalla.setStyle("-fx-font-size: 24px; -fx-alignment: center-right;");

        // --- CREACIÓN DEL TECLADO ---
        GridPane teclado = new GridPane();
        teclado.setHgap(10); teclado.setVgap(10);
        teclado.setAlignment(Pos.CENTER);
        // Array con las etiquetas de los botones
        String[] etiquetas = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "C", "0", "=", "+"
        };
        // Algoritmo para posicionar botones en una cuadrícula de 4 columnas
        int fila = 0, col = 0;
        for (String texto : etiquetas) {
            Button btn = new Button(texto);
            btn.setPrefSize(60, 60);
            btn.setOnAction(e -> procesarEntrada(texto));
            teclado.add(btn, col, fila);
            col++;
            if (col > 3) { col = 0; fila++; }
        }
        // --- ESTRUCTURA PRINCIPAL ---
        VBox raiz = new VBox(10, historial, pantalla, teclado);
        raiz.setPadding(new Insets(15));
        raiz.setAlignment(Pos.CENTER);

        primaryStage.setScene(new Scene(raiz, 300, 450));
        primaryStage.setTitle("Calculadora");
        primaryStage.show();
    }
    /**
     * los metodos para que funcionen las acciones
     */


    // para que  procese lo que entra
    private void procesarEntrada(String tecla) {
        //  Entrada de números
        if (tecla.matches("[0-9]")) {
            if (inicio) {
                pantalla.setText(tecla);
                inicio = false;
            } else {
                pantalla.appendText(tecla);
            }
            //  Reset (Botón C)
        } else if (tecla.equals("C")) {
            pantalla.setText("0");
            historial.setText("");
            num1 = 0;
            operador = "";
            inicio = true;
            //  Ejecución final (Botón =)
        } else if (tecla.equals("=")) {
            if (!operador.isEmpty()) {
                long num2 = Long.parseLong(pantalla.getText());
                calcular(num2);
                historial.setText(""); // Al dar al igual, limpiamos el historial
                operador = ""; // Finalizamos la cadena de operaciones
                inicio = true;
            }
            // Operadores
            // Si ya hay un operador y no estamos al inicio, calculamos el acumulado
            // Esto permite realizar operaciones con más de dos operandos
        } else { // Pulsamos +, -, *, /
            if (!operador.isEmpty() && !inicio) {
                // Si ya había algo pendiente, lo calculamos antes de seguir
                long num2 = Long.parseLong(pantalla.getText());
                calcular(num2);
            }

            num1 = Long.parseLong(pantalla.getText());
            operador = tecla;
            historial.setText(num1 + " " + operador); // Mostramos el acumulado arriba
            inicio = true;
        }
    }
    /**
     * Realiza la operación
     */
    private void calcular(long num2) {
        switch (operador) {
            case "+" -> num1 = num1 + num2;
            case "-" -> num1 = num1 - num2;
            case "*" -> num1 = num1 * num2;
            case "/" -> {
                if (num2 != 0) num1 = num1 / num2;
                else { pantalla.setText("Error"); return; }
            }
        }
        pantalla.setText(String.valueOf(num1));
    }

    public static void main(String[] args) { launch(args); }
}