package PROG06_Ejerc1;

/**
 *
 * @author Adrian
 */

public class Concesionario {

    private Vehiculo[] vehiculos;
    private int numVehiculos;

    public Concesionario(){
        this.numVehiculos = 0;
        this.vehiculos = new Vehiculo[50];
    }

// BUSCAMOS EL VEHICULO A TRAVES DE LA MATRICULA
    public Vehiculo buscaVehiculo(String matricula){
        for (int i = 0; i < numVehiculos; i++) {
            Vehiculo v = this.vehiculos[i];

            if(v.getMatricula().equals(matricula)){ return v;
            }
        }
        return null;
    }

// PARA CREAR UN VEHICULO
    public int insertarVehiculo(Vehiculo v){
        if (this.numVehiculos == this.vehiculos.length) { return -1;
        }
        if (this.buscaVehiculo(v.getMatricula()) != null) { return -2;
        } else {
            this.vehiculos[this.numVehiculos] = v;
            this.numVehiculos++;
            return 0;
        }
    }
// MUESTRA LOS VEHICULOS INTRODUCIDOS  O SI ESTÁ VACIO
    public void listarVehiculos() {
        if (numVehiculos == 0) {
            System.out.println("El Concesionario está vacío.");
        } else {
            for (int i = 0; i < numVehiculos; i++) {
                Vehiculo vehiculo = vehiculos[i];
                if (vehiculo != null) {
                    Vehiculo.mostrarInfo(vehiculo);
                }
            }
        }
    }




// PARA ACTUALIZAR KMS, SE INTRODUCE MATRICULA Y LOS NUEVOS KMS

    public boolean actualizaKms(String matricula, int kms){
        for (int i = 0; i < numVehiculos; i++) {
            Vehiculo v = this.vehiculos[i];


            if(v.getMatricula().equals(matricula)){
                v.setKms(kms);  return true;
            }
        }
        return false;
    }

// para  eliminar vehiculos
    public int eliminarVehiculo(String matricula) {
        int indiceEncontrado = -1;

        //  Buscar la posición del vehículo
        for (int i = 0; i < this.numVehiculos; i++) {
            if (this.vehiculos[i].getMatricula().equalsIgnoreCase(matricula)) {
                indiceEncontrado = i;
                break;
            }
        }

        //  Si no se encuentra, retornamos error (-1)
        if (indiceEncontrado == -1) {
            return -1;
        }

        //  Desplazar los elementos para compactar el array
        // Movemos cada vehículo una posición a la izquierda desde el punto de eliminación
        for (int i = indiceEncontrado; i < this.numVehiculos - 1; i++) {
            this.vehiculos[i] = this.vehiculos[i + 1];
        }

        //  Limpiar la última posición que ha quedado duplicada o vacía
        this.vehiculos[this.numVehiculos - 1] = null;

        //   restarle al contador de vehículos
        this.numVehiculos--;

        return 0;
    }



}
