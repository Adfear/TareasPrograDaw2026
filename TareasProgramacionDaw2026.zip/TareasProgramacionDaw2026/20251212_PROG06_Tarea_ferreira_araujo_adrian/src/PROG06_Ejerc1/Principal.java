
package PROG06_Ejerc1;


import PROG06_Ejerc1_util.Validar;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Scanner;


/** Se ha implementado la mejora de eliminacion de vehiculos
 *
 * @author Adrian Ferreira
 */

public class Principal {
//scanner para recibir datos
    public static void main(String[] args) {
    Scanner sn = new Scanner(System.in);
    sn.useDelimiter("\n");
    sn.useLocale(Locale.US);

    boolean salir = false;
    int opcion;
    Vehiculo v = null;

    Concesionario concesionario = new Concesionario();

    String marca, matricula, descripcion, nombreProp, ape1, ape2, propietario, dniProp;

    int km =0;
    int  dia, mes, anio;
    double precio;
    LocalDate fechaMatriculacion = null;

//menú
    while (!salir) {

        try {
            System.out.println("---- Sistema de gestion de vehiculos ----");

            System.out.println("1. Nuevo vehiculo");
            System.out.println("2. Listar Vehiculos");
            System.out.println("3. Buscar Vehiculo");
            System.out.println("4. Modificar Kms Vehiculos");
            System.out.println("5. Eliminar vehiculo");
            System.out.println("6. Salir");
            System.out.println("---- Elige una opción: ----");

// para que introduzca un numero si o si y no cualquier cosa
            if (!sn.hasNextInt()) {
                System.out.println(" Debes introducir un num entero ");
                sn.next(); // Limpiamos el búfer
                continue; // Volvemos al inicio del menú
            }

            opcion = sn.nextInt();
            sn.nextLine(); // Limpiar el salto de línea después de nextInt()
// switch para elegir en las opciones
            switch (opcion) {
                case 1:
                    System.out.println("* Introduce marca:");
                    marca = sn.next();

                    do{
                        System.out.println("* Introduce matrícula.");
                        matricula = sn.next();
                        v = concesionario.buscaVehiculo(matricula);

                        if (v != null) {
                            System.out.println("Ya existe un vehículo con esa matricula.");
                            continue;
                        }
                        if (!Validar.validarMatricula(matricula)) {
                            System.out.println(" El formato de la matrícula es incorrecto.");
                        }

                    } while (!Validar.validarMatricula(matricula) || v != null);





                    // está abajo de todo, sirve para que los datos introducidos sean correctos
                    km = leerEnteroSeguro(sn,"* Introduce el número de Kms:");
                    dia = leerEnteroSeguro(sn, "* Introduce el día de matriculación:");
                    mes = leerEnteroSeguro(sn, "* Introduce el mes:");
                    anio = leerEnteroSeguro(sn, "* Introduce el año:");
                    fechaMatriculacion = LocalDate.of(anio, mes, dia);

                    if (Validar.fechaMayorHoy(fechaMatriculacion)) {
                        throw new Exception("* La fecha de matriculación no puede ser posterior al día actual");
                    }

                    System.out.println("* Introduce la descripción");
                    descripcion = sn.next();

                    do{
                        System.out.println("* Introduce el nombre  del propietario");
                        nombreProp = sn.next();
                        System.out.println("* Introduce el primer apellido  del propietario");
                        ape1 = sn.next();
                        System.out.println("* Introduce el segundo apellido del propietario");
                        ape2 = sn.next();

                        propietario = nombreProp+ " "+ ape1+" "+ape2;
                        if (propietario.length() > 40) {
                            System.out.println("Error: El nombre completo (" + propietario.length() + " caracteres) excede el límite de 40.");
                            System.out.println("Por favor, introduce nombres o apellidos más cortos.");
                        }

                    } while (propietario.length() > 40);





                    do{
                        System.out.println("* Introduce el DNI del propietario.");
                        dniProp = sn.next();
                        if (!Validar.esValido(dniProp)) {
                            System.out.println("Error: El DNI no es válido o la letra es incorrecta.");
                        }
                    } while (!Validar.esValido(dniProp));
                    dniProp = Validar.formatearDNI(dniProp);


                    System.out.println("* Introduce el precio");
                    precio = sn.nextDouble();
                    if (precio < 0) {
                        throw new IllegalArgumentException("* El precio debe ser positivo, no me creo que sea tan barato");
                    }

                    v = new Vehiculo(marca, matricula, km, fechaMatriculacion, descripcion, precio, propietario, dniProp);
                    switch (concesionario.insertarVehiculo(v)){
                        case -2:
                            System.out.println("El vehiculo ya existe.");
                            break;
                        case -1:
                            System.out.println("El concesionario está lleno.");
                            break;
                        case 0:
                            System.out.println("Vehiculo insertado correctamente.");
                    }

                    break;


                case 2:
                    concesionario.listarVehiculos();
                    break;
                case 3:
                    System.out.println("Ingrese la matricula.");
                    matricula = sn.next();

                    v = concesionario.buscaVehiculo(matricula);

                    if (v != null) {
                        System.out.println(v.getMarca());
                        System.out.println(v.getMatricula());
                        System.out.println(v.getKms());
                        System.out.println(v.getDescripcion());


                    } else {
                        System.out.println("No existe ningún vehículo con esa matricula.");
                    }
                    break;



                case 4:
                    System.out.println("Ingrese la matricula.");
                    matricula = sn.next();
                    v = concesionario.buscaVehiculo(matricula);

                    if (v != null) {
                        System.out.println("Ingrese el nuevo numero de kilometraje.");
                        km= sn.nextInt();
                        concesionario.actualizaKms(matricula, km);
                        System.out.println("Los kilometros se han actualizado correctamente.");

                    } else {
                        System.out.println("No existe ningún vehículo con esa matricula.");
                    }
                    break;
                case 5:
                    System.out.println("Ingrese la matricula.");
                    matricula = sn.next();
                    int resultadoBorrado = concesionario.eliminarVehiculo(matricula);

                    if (resultadoBorrado == 0) {
                        System.out.println("Vehículo eliminado correctamente del sistema.");
                    } else {
                        // El método devuelve -1 si el vehículo no fue hallado
                        System.out.println("Error: No existe ningún vehículo con la matrícula introducida.");
                    }
                    break;

                case 6:
                    salir = true;
                    break;
                default:
                    System.out.println("*** Elige una opción entre 1 y 6***");


            }
        } catch (Exception e) {
            System.out.println("***  ERROR... ***");
            sn.nextLine(); // Limpieza del búfer para evitar bucle infinito


        }

    }
        sn.close();
}

// para que lo introducido sea correcto
    private static int leerEnteroSeguro(Scanner sn, String mensaje) {
        int numero = -1;
        boolean esValido = false;
        while (!esValido) {
            System.out.println(mensaje);
            if (sn.hasNextInt()) {
                numero = sn.nextInt();
                if (Validar.esPositivo(numero)) {
                    esValido = true;
                } else {
                    System.out.println(" El num debe ser positivo.");
                }
            } else {
                System.out.println("Introduce solo numero");
                sn.next();
            }
        }
        return numero;
    }
}