package PROG06_Ejerc1_util;

import java.time.LocalDate;

/**
 *
 * @author Adrian Ferreira
 */

// clase validar para comprobaciones
public class   Validar {
// en esPositivo comprobamos que el numero sea valido y mayor que 0
    public static boolean esPositivo(int num) {
        boolean b = num > 0;
        if (b) return true;
        else {
            System.out.println("Numero inválido");
            return false;
        }
    }
// aqui comprobamos que la fecha sea mayor que el dia actual, si es mayor da fallo
    public static boolean fechaMayorHoy(LocalDate fechaMatriculacion){
        LocalDate hoy = LocalDate.now(); return hoy.isBefore(fechaMatriculacion);

    }

// aqui validamos el dni pero no me funciona con minusculas, no se porque
public static boolean esValido(String dni) {
    if (dni == null) return false;

    // Comprobamos el formato básico: 8 números y 1 letra
    if (!dni.matches("\\d{8}[a-zA-Z]")) {
        return false;
    }

    // Validación de la letra oficial (Algoritmo Módulo 23)
    String numeros = dni.substring(0, 8);
    char letraDada = Character.toUpperCase(dni.charAt(8));
    String letrasValidas = "TRWAGMYFPDXBNJZSQVHLCKE";

    int indice = Integer.parseInt(numeros) % 23;
    char letraCorrecta = letrasValidas.charAt(indice);

    return letraDada == letraCorrecta;
}

    /**
     * Devuelve el DNI normalizado (en mayúsculas) si es válido.
     */
    public static String formatearDNI(String dni) {
        if (esValido(dni)) {
            return dni.substring(0, 8) + dni.substring(8).toUpperCase();
        }
        return "";
    }

    // PARA VALIDAR LA MATRICULA
    public static boolean validarMatricula(String matricula){
        String regex = "^[0-9]{4}[A-Z]{3}$";
        return matricula.matches(regex);


    }





}
