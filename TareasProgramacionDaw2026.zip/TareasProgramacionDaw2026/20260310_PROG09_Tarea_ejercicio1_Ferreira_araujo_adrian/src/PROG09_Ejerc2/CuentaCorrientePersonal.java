package PROG09_Ejerc2;

// CC personal, proviene de CC añade ComisionMantenimiento
public class CuentaCorrientePersonal extends CuentaCorriente{

    private double comisionMantenimiento;

    public CuentaCorrientePersonal(double comisionMantenimiento, String listaEntidades,
                                   Persona titular, double saldo, String IBAN) {
        super(listaEntidades, titular, saldo, IBAN);
        this.comisionMantenimiento = comisionMantenimiento;
    }

    public double getComisionMantenimiento() {
        return comisionMantenimiento;
    }

    public void setComisionMantenimiento(double comisionMantenimiento) {
        this.comisionMantenimiento = comisionMantenimiento;
    }

    @Override
    public String devolverInfoString(){
        return super.devolverInfoString() + '\n' +
                " Comision de Mantenimiento --- " + comisionMantenimiento;
    }

}