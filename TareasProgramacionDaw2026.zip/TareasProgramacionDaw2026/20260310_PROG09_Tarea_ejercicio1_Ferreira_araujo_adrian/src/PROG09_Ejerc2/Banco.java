package PROG09_Ejerc2;
import java.util.TreeMap;

// todos los imports para que funcione el .io para la generacion del txt y el dat
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
/**
 *
 * @author Adrian
 *
La estructura dinámica elegida para este caso es TreeMap debido a los siguientes motivos:
Orden automático en base al IBAN, siguiendo orden natural de la clave, que este caso es el IBAN
Eficiencia: Por lo investigado es más eficiente que un array como por ejemplo al eliminar una cuenta,
en vez de crear el método con remove(iban) funciona
Código menor y más sencillo de comprender ( en mi opinión)
Sin limite de tamaño, aumenta dinamicamente

 */

// BANCO
public class Banco {

    private TreeMap<String, CuentaBancaria> cuentas;

    public Banco() {
        // Inicializamos el mapa. Se ordenará automáticamente por el IBAN.
        this.cuentas = new TreeMap<>();
    }
    // CREA UNA NUEVA CUENTA
    public boolean abrirCuenta(CuentaBancaria c) {

        if (this.cuentas.containsKey(c.getIBAN())) {
            System.out.println("Ya existe la cuenta bancaria con ese IBAN");
            return false;
        }

        this.cuentas.put(c.getIBAN(), c);
        return true;
    }
    // MUESTRA LAS CUENTAS (Devuelve un array de Strings ordenado por IBAN)
    public String[] listadoCuentas() {
        String[] infoCuentas = new String[this.cuentas.size()];
        int i = 0;
        // El iterador del TreeMap ya recorre los elementos en orden de clave (IBAN)
        for (CuentaBancaria c : this.cuentas.values()) {
            infoCuentas[i++] = c.devolverInfoString();
        }
        return infoCuentas;
    }

    // DEVUELVE LA INFO DE UN IBAN
    public String informacionCuenta(String IBAN) {
        CuentaBancaria c = this.cuentas.get(IBAN); // Búsqueda directa
        return (c != null) ? c.devolverInfoString() : null;
    }

    // AÑADE DINERO
    public boolean ingresoCuenta(String IBAN, double cantidad) {
        CuentaBancaria c = this.cuentas.get(IBAN);
        if (c != null) {
            c.setSaldo(c.getSaldo() + cantidad);
            return true;
        }
        return false;
    }

    // RETIRA DINERO
    public boolean retiradaCuenta(String IBAN, double cantidad) {
        CuentaBancaria c = this.cuentas.get(IBAN);

        if (c != null) {
            boolean sePuedeRetirar = false;

            // Lógica de saldo suficiente
            if (c.getSaldo() - cantidad >= 0) {
                sePuedeRetirar = true;
            } else if (c instanceof CuentaCorrienteEmpresa) {
                CuentaCorrienteEmpresa aux = (CuentaCorrienteEmpresa) c;
                // Si el saldo resultante es menor que el máximo descubierto permitido
                if (Math.abs(c.getSaldo() - cantidad) <= aux.getMaximoDescubierto()) {
                    sePuedeRetirar = true;
                }
            }

            if (sePuedeRetirar) {
                c.setSaldo(c.getSaldo() - cantidad);
            }
            return sePuedeRetirar;
        }
        return false;
    }

    // DEVUELVE EL SALDO DE UN IBAN
    public double obtenerSaldo(String IBAN) {
        CuentaBancaria c = this.cuentas.get(IBAN);
        return (c != null) ? c.getSaldo() : -1;
    }

    /**
     * Elimina una cuenta en base al Iban
     */
    public int eliminarCuenta(String iban) {
        // buscamos si la cuenta existe
        CuentaBancaria cuenta = this.cuentas.get(iban);

        if (cuenta == null) {
            System.out.println("La cuenta no existe.");
            return -1;
        }
        //  saldo debe ser 0
        if (cuenta.getSaldo() != 0) {
            System.out.println("No se puede eliminar una cuenta con saldo superior a 0 (Saldo actual: " + cuenta.getSaldo() + ")");
            return -2;
        }

        //  Si existe y el saldo es 0 la eliminamos
        this.cuentas.remove(iban);
        System.out.println("Cuenta con IBAN " + iban + " eliminada correctamente.");
        return 0;
    }

    /**
     * Guarda las cuentas en un fichero binario
     */
    public void guardarCuentas() {
        // Usamos try-with-resources para asegurar el cierre
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("datoscuentasbancarias.dat"))) {

            // guarda el treemap
            for (CuentaBancaria cuenta : cuentas.values()) {
                oos.writeObject(cuenta);
            }

            System.out.println("Datos guardados correctamente.");

        } catch (FileNotFoundException ex) {
            System.err.println("Archivo no encontrado: " + ex.getMessage());
        } catch (IOException ex) {
            System.err.println("Error al escribir en el archivo: " + ex.getMessage());
        }
    }

    /**
     * Recupero las cuentas del fichero binario
     */
    public void recuperarCuentas(){
        //recuoera las cuentas
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("datoscuentasbancarias.dat"))) {

            // Cuando me quede sin cuentas, salta la excepcion EOFException
            while(true){
                CuentaBancaria cuenta = (CuentaBancaria)ois.readObject();
                this.abrirCuenta(cuenta);
            }

        } catch (FileNotFoundException ex) {
            System.out.println("No hay fichero");
        } catch (EOFException ex) {
            System.out.println("Cuentas añadidas del fichero");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

    }

    /**
     * Genera un txt con la informacion de las cuentas
     */
    public void generarListado(){
// Usamos PrintWriter con  FileWriter para escribir texto
        try (PrintWriter pw = new PrintWriter(new FileWriter("ListadoClientesCCC.txt"))) {

            pw.println("--- INFORME DE CUENTAS BANCARIAS ---");
            pw.println("Fecha de generación: " + java.time.LocalDate.now());
            pw.println("------------------------------------");

            // Recorremos los valores del TreeMap
            for (CuentaBancaria cuenta : cuentas.values()) {
                // Escribimos una línea por cada cuenta
                // mostramos los datos
                pw.println("IBAN: " + cuenta.getIBAN() + " | Titular: " + cuenta.getTitular().getNombre() +" "+
                                 cuenta.getTitular().getApellidos() +
                        " | Saldo: " + cuenta.getSaldo() + "€");
            }

            System.out.println("Archivo .txt generado con éxito.");
        // gestion de errores
        } catch (IOException ex) {
            System.err.println("Error al generar el archivo de texto: " + ex.getMessage());
        }

    }


}