package PROG09_Ejerc2;

// imprime por pantalla
public interface Imprimible {
    public String devolverInfoString();
}
