
package PROG09_Ejerc2;
import PROG09_Ejerc2_util.Validar;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author Adrian Ferreira
 */

public class Principal {
//scanner para recibir datos
    public static void main(String[] args) {
    Scanner sn = new Scanner(System.in);
    sn.useDelimiter("\n");
    sn.useLocale(Locale.US);

    boolean salir = false;
    int opcion, tipoCuenta;

    String nombreTitular, apellidosTitular, DNITitular, IBAN, listaAutorizadas, infoCuenta;
    String[] listaCuentas;

    Persona titular;
    double saldo, tipoInteres, comisionMantenimiento, tipoInteresDescubierto, maxDescubierto,
                comisionDescubierto, cantidad;

    Banco banco = new Banco();
    banco.recuperarCuentas();
    CuentaBancaria cuenta = null;

    //llama al metodo recuperarCuentas()


//menú
    while (!salir) {

        try {
            System.out.println("---- SISTEMA DE GESTION BANCARIA ----");
            System.out.println("1. Abrir una nueva cuenta.");
            System.out.println("2. Ver un listado de las cuentas disponibles");
            System.out.println("3. Obtener los datos de una cuenta concreta.");
            System.out.println("4. Realizar un ingreso en una cuenta.");
            System.out.println("5. Retirar efectivo de una cuenta.");
            System.out.println("6. Consultar el saldo actual de una cuenta.");
            System.out.println("7. Eliminar Cuenta");
            System.out.println("8. Generar listado Clientes.");
            System.out.println("9. Salir de la aplicación.");
            System.out.println("---- Elige una opción: ----");


// para que introduzca un numero si o si y no cualquier cosa
            if (!sn.hasNextInt()) {
                System.out.println(" Debes introducir un num entero ");
                sn.next(); // Limpiamos el búfer
                continue; // Volvemos al inicio del menú
            }

            opcion = sn.nextInt();
            sn.nextLine(); // Limpiar el salto de línea después de nextInt()
// switch para elegir en las opciones
            switch (opcion) {
                case 1:
                    // Datos del Propietario
                    System.out.println("* Introduce el nombre del titular:");
                    nombreTitular = sn.next();

                    System.out.println("* Introduce los apellidos del titular:");
                    apellidosTitular = sn.next();

                    // Validación  del DNI
                    do {
                        System.out.println("* Introduce el DNI del titular:");
                        DNITitular = sn.next();
                        if (!Validar.esValido(DNITitular)) {
                            System.out.println("Error: El DNI no es válido o la letra es incorrecta.");
                        }
                    } while (!Validar.esValido(DNITitular));
                    DNITitular = Validar.formatearDNI(DNITitular);

                    titular = new Persona(nombreTitular, apellidosTitular, DNITitular);

                    // Validación del IBAN
                    do {
                        System.out.println("* Introduce el IBAN (ES + 20 dígitos):");
                        IBAN = sn.next();
                        if (!IBAN.matches("^ES[0-9]{20}$")) {
                            System.out.println("Error: El formato del IBAN es incorrecto (Ej: ES12345678901234567890).");
                        }
                    } while (!IBAN.matches("^ES[0-9]{20}$"));

                    // Lectura de saldo usando método seguro
                    saldo = leerDoubleSeguro(sn, "* Introduce el saldo inicial:");

                    System.out.println("Elige el tipo de cuenta:");
                    System.out.println("1. Cuenta ahorro");
                    System.out.println("2. Cuenta corriente personal");
                    System.out.println("3. Cuenta corriente empresa");
                    tipoCuenta = sn.nextInt();
                    sn.nextLine(); // Limpiar búfer

                    switch (tipoCuenta) {
                        case 1:
                            tipoInteres = leerDoubleSeguro(sn, "* Introduce el tipo de interés:");
                            cuenta = new CuentaAhorro(tipoInteres, titular, saldo, IBAN);
                            break;
                        case 2:
                            System.out.println("* Introduce lista de entidades autorizadas:");
                            listaAutorizadas = sn.next();
                            comisionMantenimiento = leerDoubleSeguro(sn, "* Introduce la comisión de mantenimiento:");
                            cuenta = new CuentaCorrientePersonal(comisionMantenimiento, listaAutorizadas, titular, saldo, IBAN);
                            break;
                        case 3:
                            System.out.println("* Introduce lista de entidades autorizadas:");
                            listaAutorizadas = sn.next();
                            tipoInteresDescubierto = leerDoubleSeguro(sn, "* Introduce el tipo de interés descubierto:");
                            maxDescubierto = leerDoubleSeguro(sn, "* Introduce el máximo descubierto permitido:");
                            comisionDescubierto = leerDoubleSeguro(sn, "* Introduce la comisión por descubierto:");
                            cuenta = new CuentaCorrienteEmpresa(maxDescubierto, tipoInteresDescubierto, comisionDescubierto, listaAutorizadas, titular, saldo, IBAN);
                            break;
                        default:
                            throw new Exception("Opción de tipo de cuenta no válida.");
                    }

                    // Intentar abrir la cuenta en el banco
                    if (banco.abrirCuenta(cuenta)) {
                        System.out.println("Se ha abierto la cuenta con éxito.");
                    } else {
                        System.out.println("Error: No se pudo abrir la cuenta (IBAN duplicado o banco lleno).");
                    }
                    break;

                case 2:
                    // info cuentas en general
                    listaCuentas = banco.listadoCuentas();
                    if (listaCuentas.length == 0) {
                        System.out.println("No hay cuentas registradas.");
                    } else {
                        for (String s : listaCuentas) {
                            System.out.println(s);
                        }
                    }
                    break;

                case 3:
                    // info de cuenta en base iban
                    System.out.println("Introduce el IBAN:");
                    IBAN = sn.next();
                    infoCuenta = banco.informacionCuenta(IBAN);
                    System.out.println(infoCuenta != null ? infoCuenta : "La cuenta no existe.");
                    break;

                case 4:
                    // añadir dinero en base de iban
                    System.out.println("Introduce el IBAN:");
                    IBAN = sn.next();
                    cantidad = leerDoubleSeguro(sn, "Introduce cantidad a ingresar:");
                    if (banco.ingresoCuenta(IBAN, cantidad)) {
                        System.out.println("Ingreso realizado correctamente.");
                    } else {
                        System.out.println("Error al realizar el ingreso (Cuenta inexistente).");
                    }
                    break;

                case 5:
                    // retirar dinero en base de iban
                    System.out.println("Introduce el IBAN:");
                    IBAN = sn.next();
                    cantidad = leerDoubleSeguro(sn, "Introduce cantidad a retirar:");
                    if (banco.retiradaCuenta(IBAN, cantidad)) {
                        System.out.println("Retirada realizada correctamente.");
                    } else {
                        System.out.println("Error al retirar: Saldo insuficiente o cuenta no válida.");
                    }
                    break;

                case 6:
                    //saldo en base de iban
                    System.out.println("Introduce el IBAN:");
                    IBAN = sn.next();
                    double s = banco.obtenerSaldo(IBAN);
                    if (s != -1) {
                        System.out.println("El saldo actual es: " + s + "€");
                    } else {
                        System.out.println("La cuenta no existe.");
                    }
                    break;


                case 7:
                    // para eliminar cuenta en base de iban
                    System.out.println("Introduce el IBAN:");
                    IBAN = sn.next();
                    banco.eliminarCuenta(IBAN);

                    break;


                case 8:
                    // genera el txt con los datos actualizados
                    banco.generarListado();
                    System.out.println("Listado generado");
                    break;

                case 9:
                    // para salir del programa
                    salir = true;
                    // al salir guarda las cuentas en el .dat
                    banco.guardarCuentas();
                    break;
                default:
                    System.out.println("*** Elige una opción entre 1 y 8***");


            }
        } catch (Exception e) {
            System.out.println("***  ERROR... ***");
            sn.nextLine(); // Limpieza del búfer para evitar bucle infinito


        }

    }
        sn.close();
}

// para que lo introducido sea correcto
    private static int leerEnteroSeguro(Scanner sn, String mensaje) {
        int numero = -1;
        boolean esValido = false;
        while (!esValido) {
            System.out.println(mensaje);
            if (sn.hasNextInt()) {
                numero = sn.nextInt();
                if (Validar.esPositivo(numero)) {
                    esValido = true;
                } else {
                    System.out.println(" El num debe ser positivo.");
                }
            } else {
                System.out.println("Introduce solo numero");
                sn.next();
            }
        }
        return numero;
    }

// para que lo introducido sea correcto, igual que el anterior pero admitiendo decimales

    private static double leerDoubleSeguro(Scanner sn, String mensaje) {
        double numero = -1;
        boolean esValido = false;
        while (!esValido) {
            System.out.println(mensaje);
            if (sn.hasNextDouble()) {
                numero = sn.nextDouble();
                if (Validar.esPositivo((int)numero) || numero >= 0) {
                    esValido = true;
                } else {
                    System.out.println("El valor debe ser positivo.");
                }
            } else {
                System.out.println("Error: Introduce solo números (decimales con punto).");
                sn.next(); // Limpiar búfer
            }
        }
        return numero;
    }
}