package tareas.prog04;

import java.util.Scanner;

/**
 *Ejercicio 1: Implementar un programa que muestre la tabla de multiplicar de un número leido
 * desde teclado utilizando al menos tres bucles diferentes.
 * El número leído desde teclado debe ser menor que 30.
 * En caso contrario se mostrará un mensaje por pantalla y el programa finalizará
 * * @author Adrian Ferreira Araujo
 *
 */
public class PROG04_Ejerc1 {
    /**
     * Método main que gestiona la lectura del número y la ejecución
     * de los tres bucles para mostrar la tabla de multiplicar
     */
    public static void main(String[] args) {
        Scanner sn = new Scanner(System.in);
        // scanner para introducir datos por teclado
        System.out.print("Introduce un número entero menor que 30: ");
        int num = sn.nextInt();
        // Validación numero menor  a 30
        if (num >= 30) {
            System.out.println("Error: El número introducido debe ser menor que 30. El programa finalizará.");
        } else {
            System.out.println("\n--- TABLA DE MULTIPLICAR DE " + num + " ---");

            //  Bucle FOR
            System.out.println("\n--- Resultado con bucle FOR ---");
            for (int i = 1; i <= 10; i++) {
                System.out.println(num + " x " + i + " = " + (num *i));
            }

            // Bucle WHILE
            System.out.println("\n--- Resultado con bucle WHILE ---");
            int j = 1;
            while (j <= 10) {
                System.out.println(num + " x " + j + " = " + (num *j));
                j++;
            }

            //  Bucle DO-WHILE
            System.out.println("\n--- Resultado con bucle DO-WHILE ---");
            int k = 1;
            do {
                System.out.println(num + " x " + k + " = " + (num *k));
                k++;
            } while (k <= 10);
        }

        sn.close();
    }
}