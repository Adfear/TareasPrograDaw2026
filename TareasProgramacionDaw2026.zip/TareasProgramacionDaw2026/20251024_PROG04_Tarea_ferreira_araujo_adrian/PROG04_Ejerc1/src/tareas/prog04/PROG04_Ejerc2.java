package tareas.prog04;

import java.util.Scanner;

/**
 * Ejercicio 2: Un número es primo si solo tiene dos divisores: el 1 y el propio número. Implementa
 * un programa Java que pida por teclado 5 números. Para cada uno de ellos:
 * o Comprueba si es negativo. En caso afirmativo, muestra el mensaje por pantalla "El número
 * es negativo".
 * o Si es positivo, deberá mostrar por pantalla si es primo o no.
 * o Procesados los 5 números, el programa finaliza.
 * * @author Adrian Ferreira Araujo
 * @version 1.0
 */
public class PROG04_Ejerc2 {

    /**
     * Método main que gestiona el bucle para procesar exactamente 5 números
     */
    public static void main(String[] args) {
        Scanner sn = new Scanner(System.in);
        final int TOTAL_NUM = 5;
        System.out.println("Introduce " + TOTAL_NUM + " números enteros:");

        for (int i = 1; i <= TOTAL_NUM; i++) {
            System.out.print("Número " + i + ": ");
            int num = sn.nextInt();

            if (num< 0) {
                System.out.println("El número es negativo");
            } else {
                if (esPrimo(num)) {
                    System.out.println("El número " + num + " es primo.");
                } else {
                    System.out.println("El número " + num + " NO es primo.");
                }
            }
            System.out.println("------------------------------------");
        }

        System.out.println("Procesados los " + TOTAL_NUM + " números. El programa ha finalizado");
        sn.close();
    }

    /**
     * Método que evalúa si un número entero positivo es primo
     * Un número es primo si solo es divisible por 1 y por sí mismo
     * * @param num El número entero a evaluar
     * @return true si el número es primo, false en caso contrario
     */
    public static boolean esPrimo(int num) {
        // Los números menores o iguales a 1 no se consideran primos
        if (num <= 1) {
            return false;
        }
        // Comprobamos si tiene algún divisor entre 2 y la raíz cuadrada del número
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false; // Se encontró un divisor no es primo
            }
        }
        return true; // No se encontraron divisores es primo
    }
}