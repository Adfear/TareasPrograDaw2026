package tareas.prog04;

import java.util.Scanner;

/**
 * Ejercicio 4: Deseamos implementar un juego en Java que permita al usuario adivinar un número
 * oculto (que será aleatorio). El funcionamiento será el siguiente:
 * o El programa mostrará un pequeño menú en pantalla con las siguientes opciones (1.
 * Configurar, 2. Jugar, 3. Salir).
 *  Si el usuario selecciona el la primera opción, se le solicitará por teclado el número
 * de intentos permitidos (numInt) y el número máximo (numMax) generado.
 *  Si el usuario selecciona la opción 2, el programa generará un número aleatorio
 * entre 0 y numMax que será el número a adivinar (numOculto). A partir de este
 * momento, se le solicitarán al usuario números hasta adivinar el número oculto.
 *  Si el usuario adivina el número, se mostrará un mensaje "Has ganado!.
 * Has necesitado X intentos".
 *  Si se consume el número de intentos sin adivinar el número, se mostrará
 * el mensaje "Perdiste!. Intentos consumidos".
 *  En cada intento, si el usuario no adivina el número se le proporcionará una
 * pista, por ejemplo, "El número oculto es menor".
 *  En ambos casos, la siguiente acción será mostrar el menú.
 *  Si el usuario selecciona Jugar sin configurar previamente el número de
 * intentos y el número máximo generado, se tomarán como valores por
 * defecto: numInt=5 y numMax=10.
 *  Si el usuario pulsa la opción 3, el programa finaliza.
 * o Para generar un número aleatorio en java puedes utilizar el siguiente código:
 * int numOculto = (int)Math.floor(Math.random()*20+1); //genera un número aleatorio entre 0 y 20, ambos incluidos.
 *
 *  @author Adrian Ferreira Araujo
 * @version 1.0
 */
public class PROG04_Ejerc4 {

    /**
     * Método principal que gestiona el bucle del menú y las acciones
     *  de cada opción (Configurar, Jugar y Salir)
     */
    public static void main(String[] args) {
        Scanner sn = new Scanner(System.in);
        // Valores por defecto
        int numInt = 5;
        int numMax = 10;
        int opcion;

        do {
            //  menú
            System.out.println("\n---JUEGO DEL NÚMERO OCULO ---");
            System.out.println("1. Configurar");
            System.out.println("2. Jugar");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sn.nextInt();

            switch (opcion) {
                case 1:
                    // Configuración de parámetros
                    System.out.print("Introduce el número de intentos permitidos: ");
                    numInt = sn.nextInt();
                    System.out.print("Introduce el número máximo generado (rango de 0 a X): ");
                    numMax = sn.nextInt();
                    System.out.println("--- Configuración guardada con éxito ---");
                    break;

                case 2:
                    // Lógica del juego
                    // Genera un número aleatorio entre 0 y numMax (ambos incluidos)
                    int numOculto = (int) Math.floor(Math.random() * (numMax + 1));
                    int intentosConsumidos = 0;
                    boolean adivinado = false;

                    System.out.println("Se ha generado un número entre 0 y " + numMax + " Tienes " + numInt + " intentos");

                    while (intentosConsumidos < numInt && !adivinado) {
                        System.out.print("Intento " + (intentosConsumidos + 1) + " Introduce tu número: ");
                        int numeroUsuario = sn.nextInt();
                        intentosConsumidos++;

                        if (numeroUsuario == numOculto) {
                            adivinado = true;
                            System.out.println("¡Has ganado!. Has necesitado " + intentosConsumidos + " intentos");
                        } else if (intentosConsumidos < numInt) {
                            // Si no ha acertado y aún le quedan intentos, damos una pista
                            if (numOculto < numeroUsuario) {
                                System.out.println("Pista: El número oculto es menor.");
                            } else {
                                System.out.println("Pista: El número oculto es mayor.");
                            }
                        }
                    }

                    if (!adivinado) {
                        System.out.println("Perdiste! Intentos consumidos. El número era: " + numOculto);
                    }
                    break;

                case 3:
                    System.out.println("Programa finalizado");
                    break;

                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }

        } while (opcion != 3);
        sn.close();
    }
}