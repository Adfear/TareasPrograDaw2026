package tareas.prog04;
import java.util.Scanner;

/**
 * Ejercicio 5: Cuando dividimos un número entre 0 se genera un valor indeterminado. En cualquier
 * lenguaje de programación este tipo de operaciones genera un error de ejecución que debe ser
 * controlado desde el código para evitar malas experiencias al usuario.
 * En Java, cuando se produce esta operación se genera la excepción ArithmeticException.
 * Queremos implementar un programa Java
 * que calcule la división de dos números solicitados por teclado (dividendo y divisor).
 * El programa solicitará números indefinidamente hasta que los dos números solicitados sean -1.
 * Se debe controlar (el alumno elegirá mediante excepciones o mediante otra forma) que el divisor
 * no sea 0. En caso de serlo, se mostrará un mensaje por pantalla. También habrá que mostrar por
 * pantalla el número de divisiones calculadas. Utiliza número enteros para las variables
 *
 * * @author Adrian Ferreira Araujo
 */


public class PROG04_Ejerc5 {

    /**
     * Método main que solicita los datos numéricos, gestiona el bucle de
     * control, captura excepciones aritméticas y cuenta las divisiones exitosas
     */

    public static void main(String[] args) {
        Scanner sn = new Scanner(System.in);

        int dividendo, divisor;
        int divisionesCalculadas = 0;

        System.out.println("Calculadora de Divisiones Enteras Continua");
        System.out.println("Para salir, introduce -1 tanto en el dividendo como en el divisor\n");

        while (true) {
            System.out.print("Introduce el dividendo: ");
            dividendo = sn.nextInt();
            System.out.print("Introduce el divisor: ");
            divisor = sn.nextInt();

            // Condición de parada: que ambos sean -1
            if (dividendo == -1 && divisor == -1) {
                break;
            }

            // Bloque de control de excepciones
            try {
                // En Java, la división entera (/) entre 0 lanza automáticamente un ArithmeticException
                int resultado = dividendo / divisor;
                System.out.println("Resultado: " + dividendo + " / " + divisor + " = " + resultado);
                divisionesCalculadas++; // Solo suma si la operación fue exitosa

            } catch (ArithmeticException e) {
                System.out.println("Error: No se puede dividir entre cero. Intente con otro divisor");
            }

            System.out.println("-------------------------------------------------");
        }

        // Cierre del programa y muestra del contador
        System.out.println("\nPrograma finalizado.");
        System.out.println("Total de divisiones calculadas con éxito: " + divisionesCalculadas);
        sn.close();
    }
}