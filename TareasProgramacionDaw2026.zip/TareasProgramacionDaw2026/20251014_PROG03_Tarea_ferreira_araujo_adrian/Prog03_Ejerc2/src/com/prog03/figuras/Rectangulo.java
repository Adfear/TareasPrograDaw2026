package com.prog03.figuras;

public class Rectangulo {

    // Atributos para la base y la altura
    private float base;
    private float altura;

    // Constructor vacío: inicializa los atributos a 0
    public Rectangulo() {
        this.base = 0.0f;
        this.altura = 0.0f;
    }

    // Constructor que inicializa base y altura con los valores recibidos
    public Rectangulo(float base, float altura) {
        this.base = base;
        this.altura = altura;
    }

    // --- Métodos Getter y Setter ---

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }


    /**
     * Calcula y devuelve el área del rectángulo (Base * Altura)
     */
    public float getArea() {
        return this.base * this.altura;
    }

    /**
     * Devuelve una cadena con la base y la altura del rectángulo.
     */
    @Override
    public String toString() {
        return "Rectángulo [Base: " + this.base + ", Altura: " + this.altura + ", Área: " + getArea() + "]";
    }

    /**
     * Devuelve true si la base es igual a la altura (un cuadrado)
     */
    public boolean isCuadrado() {
        return this.base == this.altura;
    }
}
