package com.prog03.Principal;

// Importamos la clase Rectangulo desde su paquete correspondiente
import com.prog03.figuras.Rectangulo;

public class principal {

    public static void main(String[] args) {
        System.out.println("--- Probando el Constructor Vacío ---");
        //  rectángulo sin dimensiones usando constructor vacío
        Rectangulo r1 = new Rectangulo();
        System.out.println("Estado inicial r1: " + r1);
        // Modificamos sus atributos usando los setters
        r1.setBase(5.5f);
        r1.setAltura(5.5f); // Le damos los mismos valores para que sea un cuadrado
        System.out.println("Estado modificado r1: " + r1);
        System.out.println("¿Es un cuadrado r1?: " + (r1.isCuadrado() ? "Sí" : "No"));
        System.out.println("Área de r1: " + r1.getArea());
        System.out.println("\n--- Probando el Constructor con Parámetros ---");
        // Instancia de un rectángulo pasando base y altura directamente
        Rectangulo r2 = new Rectangulo(8.0f, 4.5f);
        System.out.println("Datos de r2: " + r2);
        System.out.println("¿Es un cuadrado r2?: " + (r2.isCuadrado() ? "Sí" : "No"));
        System.out.println("Área de r2: " + r2.getArea());
    }
}
