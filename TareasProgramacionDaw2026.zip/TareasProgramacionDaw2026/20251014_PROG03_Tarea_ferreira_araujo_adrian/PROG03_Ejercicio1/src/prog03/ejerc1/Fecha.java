package prog03.ejerc1;
/***
 * Ejercicio 1
 * @author adrian ferreira araujo
 */
public class Fecha {

    // Declaración del tipo enumerado para los meses
    public enum enumMes {
        ENERO, FEBRERO, MARZO, ABRIL, MAYO, JUNIO,
        JULIO, AGOSTO, SEPTIEMBRE, OCTUBRE, NOVIEMBRE, DICIEMBRE
    }

    // Atributos de la clase, dia, mes y año
    private int dia;
    private enumMes mes;
    private int anio;

    // Primer constructor: inicializa el mes y los demás atributos a 0
    public Fecha(enumMes mes) {
        this.dia = 0;
        this.mes = mes;
        this.anio = 0;
    }

    // Segundo constructor: inicializa todos los atributos
    public Fecha(int dia, enumMes mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    // --- Métodos Getter y Setter ---

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public enumMes getMes() {
        return mes;
    }

    public void setMes(enumMes mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    /**
     * Devuelve true si el mes es de verano (Junio, Julio o Agosto)
     */
    public boolean isSummer() {
        return this.mes == enumMes.JUNIO || this.mes == enumMes.JULIO || this.mes == enumMes.AGOSTO;
    }

    /**
     * Devuelve la fecha en formato largo
     * Ejemplo: " 15 de julio de 2020"
     */

    @Override
    public String toString() {
        return this.dia + " de " + this.mes + " de " + this.anio;
    }
}