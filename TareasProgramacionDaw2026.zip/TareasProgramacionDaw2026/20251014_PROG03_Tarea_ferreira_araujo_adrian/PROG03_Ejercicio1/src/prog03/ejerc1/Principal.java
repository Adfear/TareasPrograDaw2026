package prog03.ejerc1;
/***
 * Ejercicio 1
 * @author adrian ferreira araujo
 *
 */
// main
public class Principal {
    public static void main(String[] args) {

        // --- PRUEBA 1: Primer constructor ---
        System.out.println("Primera fecha, inicializada con el primer constructor");
        // Instancia con el primer constructor
        Fecha objFecha1 = new Fecha(Fecha.enumMes.FEBRERO);
        // Actualizamos el día y el año usando los setters
        objFecha1.setDia(20);
        objFecha1.setAnio(2000);
        // Mostramos la fecha
        System.out.println("La fecha es: " + objFecha1);
        // Mostramos si es verano usando el operador ternario
        String mensajeVerano1 = objFecha1.isSummer() ? "Es verano" : "No es verano";
        System.out.println(mensajeVerano1);
        System.out.println(); // Salto de línea para separar las pruebas
        // --- PRUEBA 2: Segundo constructor ---
        System.out.println("Segunda fecha, inicializada con el segundo constructor");
        // Instancia con todos los parámetros
        Fecha objFecha2 = new Fecha(15, Fecha.enumMes.JULIO, 2015);
        // Mostramos el año utilizando el getter
        System.out.println("La fecha 2 contiene el año " + objFecha2.getAnio());
        // Mostramos la fecha completa
        System.out.println("La fecha es: " + objFecha2);
        // Mostramos si es verano con el operador ternario
        String mensajeVerano2 = objFecha2.isSummer() ? "Es verano" : "No es verano";
        System.out.println(mensajeVerano2);
    }
}

