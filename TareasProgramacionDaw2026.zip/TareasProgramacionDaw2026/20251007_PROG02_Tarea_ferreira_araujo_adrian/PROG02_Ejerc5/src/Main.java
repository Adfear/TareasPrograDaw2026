//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int segundosTotales = 1234567; // Ejemplo de segundos a evaluar
        // Cálculos de conversión
        int dias = segundosTotales / (24 * 3600);
        int restoSegundos = segundosTotales % (24 * 3600);
        int horas = restoSegundos / 3600;
        restoSegundos = restoSegundos % 3600;
        int minutos = restoSegundos / 60;
        int segundos = restoSegundos % 60;

        System.out.println(segundosTotales + " segundos equivalen a:");
        System.out.println(dias + " días, " + horas + " horas, "
                + minutos + " minutos y " + segundos + " segundos");
    }
}