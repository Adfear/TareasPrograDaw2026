//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int anio = 1900; // Cambia este valor para probar
        // Expresión booleana condicional
        boolean esBisiesto = (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
        String mensaje = esBisiesto ? "es bisiesto." : "no es bisiesto";
        System.out.println("El año " + anio + " " + mensaje);
        }
    }
