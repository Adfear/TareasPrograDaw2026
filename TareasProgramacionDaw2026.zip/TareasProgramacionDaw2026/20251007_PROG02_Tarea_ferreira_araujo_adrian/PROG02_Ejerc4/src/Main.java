
public class Main {
    public static void main(String[] args) {
        int edad = 20; // Cambiamos este valor para probar
        String resultado = (edad >= 18) ? "Es mayor de edad" : "Es menor de edad";
        System.out.println("Edad: " + edad + " -> " + resultado);
        }
    }