//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        double c1 = 3.5;
        double c2 = -7.2;
        // C1x + C2 = 0 -> x = -C2 / C1
        double x = -c2 / c1;
        System.out.printf("El resultado de la ecuación %.2fx + (%.2f) = 0 es x = %.4f\n", c1, c2, x);
        }
    }
