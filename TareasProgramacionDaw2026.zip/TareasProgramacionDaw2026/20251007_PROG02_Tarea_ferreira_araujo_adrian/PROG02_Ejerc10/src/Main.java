//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
// --- Bloque 1 ---
        float x = 4.5f;
        float y = 3.0f;
        int i = 2;
        int j = (int) (i * x);
        double dx = 2.0;
        double dz = dx * y;
        System.out.println("------- Conversiones entre enteros y coma flotante -------");
        System.out.println("Producto de int por float: j= i*x = " + j);
        System.out.println("Producto de float por double: dz=dx * y = " + dz);

        // --- Bloque 2 ---
        byte bx = 5;
        byte by = 2;
        byte bz = (byte) (bx - by);
        System.out.println("------- Operaciones con byte -------");
        System.out.println("byte: " + bx + " - " + by + " = " + bz);
        bx = -128;
        by = 1;
        bz = (byte) (bx - by);
        System.out.println("byte -128 - 1 = " + bz);
        int bzInt = bx - by;
        System.out.println("(int)(-128 - 1) = " + bzInt);
        // --- Bloque 3 ---
        short sx = 10;
        short sy = 1;
        short sz = (short) (sx - sy);
        System.out.println("------- Operaciones con short -------");
        System.out.println("short: 10 - 1 = " + sz);
        sx = 32767;
        sy = 1;
        sz = (short) (sx + sy);
        System.out.println("short 32767 + 1 = " + sz);

        // --- Bloque 4 ---
        char cx = '\u000F';
        char cy = '\u0001';
        int z = cx - cy;
        System.out.println("------- Operaciones con char -------");
        System.out.println("char: - = " + z);
        z = cx - 1;
        System.out.println("char(0x000F) - 1 = " + z);
        cx = '\uFFFF';
        z = cx;
        System.out.println("(int)( ) = " + z);
        sx = (short) cx;
        System.out.println("(short)( ) = " + sx);
        sx = -32768;
        cx = (char) sx;
        z = cx;
        System.out.println("-32768 short-char-int = " + z);
        sx = -1;
        cx = (char) sx;
        z = cx;
        System.out.println("-1 short-char-int = " + z);
    }
}