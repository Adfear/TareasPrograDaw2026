//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int proga = 45;
        int entornos = 23;
        int bbdd = 31;
        int totalAlumnos = proga + entornos + bbdd;
        // Cálculo de porcentajes pasando un operando a double
        double porcProga = ((double) proga / totalAlumnos) * 100;
        double porcEntornos = ((double) entornos / totalAlumnos) * 100;
        double porcBbdd= ((double) bbdd / totalAlumnos) * 100;
        System.out.println("Total de alumnos matriculados: " + totalAlumnos);
        System.out.printf("Porcentaje en Programación: %.1f%%\n", porcProga);
        System.out.printf("Porcentaje en Bases de Datos: %.1f%%\n", porcBbdd);
        }
    }
