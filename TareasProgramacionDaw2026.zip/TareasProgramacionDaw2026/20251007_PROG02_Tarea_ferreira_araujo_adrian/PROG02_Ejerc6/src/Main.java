//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // Definición del enum
        enum RazasPerro { Mastin, Terrier, Bulldog, Pekines, Caniche, Galgo }

            RazasPerro var1 = RazasPerro.Bulldog;
            RazasPerro var2 = RazasPerro.Galgo;
            // Comparación de variables .compareTo devuelve la diferencia de posiciones
            int comparacion = var1.compareTo(var2);
            System.out.println("Resultado de comparar var1 con var2: " + comparacion);
            // Total de elementos y posiciones ocupadas
            System.out.println("Cantidad total de valores en el enum: " + RazasPerro.values().length);
            System.out.println("Posición de var1 (" + var1 + "): " + var1.ordinal());
            System.out.println("Posición de var2 (" + var2 + "): " + var2.ordinal());
        }
    }