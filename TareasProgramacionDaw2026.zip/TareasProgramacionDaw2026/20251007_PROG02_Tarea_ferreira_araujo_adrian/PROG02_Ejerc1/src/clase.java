public class clase {
    public static void main(String[] args) {
        // 1. Valor máximo no modificable: 5000
        // final para que sea constante y short porque es un  valor pequeño,
        // short admite de -32.768 a 32.767, menos que int
        final short MAX_VALOR = 5000;
        // 2. Si el nuevo empleado tiene carnet de conducir o no
        // boolean admite true o false, y es lo que se pide, un si o un no
        boolean tieneCarnet = true;
        // 3. Un mes del año en formato numérico y como cadena
        // byte comprende de -128 a 127, pequeño para contener 3
        // string es para cadenas
        byte mesNumerico = 3;
        String mesCadena = "Marzo";
        // 4. El nombre y apellidos de una persona
        // string para cadenas
        String nombreCompleto = "Adrian Ferreira Araujo ";
        // 5. Sexo: con dos valores posibles 'V' o 'M'
        // se podria usar char para una sola, porque almacena un unico caracter pero enum admite ambos
        // y deja elegir uno de los disponibles
        enum Sexo { V, M }
        Sexo sexoUsuario = Sexo.V;
        // 6. Milisegundos transcurridos desde el 01/01/1970 hasta nuestros días
        // long es el mas grande que hay
        long milisegundos = System.currentTimeMillis();
        // 7. Saldo de una cuenta bancaria
        // double para decimales
        double saldoCuenta = 2150.85;
        // 8. Distancia en kms desde la Tierra a Júpiter (mínima aprox. 588 millones km)
        // long es el mas grande que hay, y el anterior es demasiado pequeño ( int)
        long distanciaJupiter = 588000000L;
        // Salida por pantalla usando print() y \n
        System.out.print("1. Valor máximo final: " + MAX_VALOR + "\n");
        System.out.print("2. ¿Tiene carnet de conducir?: " + tieneCarnet + "\n");
        System.out.print("3. Mes numérico: " + mesNumerico + " | Mes cadena: " + mesCadena + "\n");
        System.out.print("4. Nombre y apellidos: " + nombreCompleto + "\n");
        System.out.print("5. Sexo: " + sexoUsuario + "\n");
        System.out.print("6. Milisegundos desde 1970: " + milisegundos + "\n");
        System.out.print("7. Saldo de la cuenta: " + saldoCuenta + " €\n");
        System.out.print("8. Distancia a Júpiter: " + distanciaJupiter + " km\n");
    }
}


