package PROG07_Ejerc1;

// CC Empreesa, proviene de CC añade MaximoDescubierto, tipoInteresDescubierto, ComisionFijaDescubierto
//Getters y setters

public class CuentaCorrienteEmpresa extends CuentaCorriente {

    private double maximoDescubierto;
    private double tipoInteresDescubierto;
    private double comisiónFijaDescubierto;

    public CuentaCorrienteEmpresa(double maximoDescubierto, double tipoInteresDescubierto,
                                  double comisiónFijaDescubierto, String listaEntidades, Persona titular,
                                  double saldo, String IBAN) {
        super(listaEntidades, titular, saldo, IBAN);
        this.maximoDescubierto = maximoDescubierto;
        this.tipoInteresDescubierto = tipoInteresDescubierto;
        this.comisiónFijaDescubierto = comisiónFijaDescubierto;
    }

    public double getMaximoDescubierto() {
        return maximoDescubierto;
    }

    public void setMaximoDescubierto(double maximoDescubierto) {
        this.maximoDescubierto = maximoDescubierto;
    }

    public double getTipoInteresDescubierto() {
        return tipoInteresDescubierto;
    }

    public void setTipoInteresDescubierto(double tipoInteresDescubierto) {
        this.tipoInteresDescubierto = tipoInteresDescubierto;
    }

    public double getComisiónFijaDescubierto() {
        return comisiónFijaDescubierto;
    }

    public void setComisiónFijaDescubierto(double comisiónFijaDescubierto) {
        this.comisiónFijaDescubierto = comisiónFijaDescubierto;
    }

    @Override
    public String devolverInfoString(){
        return super.devolverInfoString() + '\n' +
                " Maximo de Descubierto = " +
                maximoDescubierto + '\n' +
                " Tipo Interes Descubierto = " + tipoInteresDescubierto + '\n' +
                " Comision Fija Descubierto = " + comisiónFijaDescubierto    ;
    }


}