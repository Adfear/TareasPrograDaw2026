package PROG07_Ejerc1;

// imprime por pantalla
public interface Imprimible {
    public String devolverInfoString();
}
