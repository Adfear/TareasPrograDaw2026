
package PRO10_2_util;
import java.time.LocalDate;

/**
 *
 * @author Adrian Ferreira
 */

// clase validar para comprobaciones
public class   Validar {
// en esPositivo comprobamos que el numero sea valido y mayor que 0
    public static boolean esPositivo(int num) {
        boolean b = num > 0;
        if (b) return true;
        else {
            System.out.println("Numero inválido");
            return false;
        }
    }
// aqui comprobamos que la fecha sea mayor que el dia actual, si es mayor da fallo
    public static boolean fechaMayorHoy(LocalDate fechaMatriculacion){
        LocalDate hoy = LocalDate.now(); return hoy.isBefore(fechaMatriculacion);

    }

// aqui validamos el dni
public static String validarDNI(String dni) {
    // Aceptamos 8 números y una letra (mayúscula o minúscula)
    if (dni.matches("\\d{8}[a-zA-Z]")) {
        return dni.toUpperCase(); // Lo devolvemos siempre en mayúsculas
    } else {
        return "";
    }
}
 /* aqui validamos el formato de la matricula,
 también acepta las matriculas antiguas españolas ya que tengo un coche del
    92 y asi lo incluyo en los ejemplos
  */
    public static boolean validarFormatoMatricula(String matricula) {
        // El método matches devuelve true si el texto cumple el patrón
        return matricula.matches("^([0-9]{4}[A-Z]{3})|([A-Z]{1,2}[0-9]{4}[A-Z]{1,2})$");
    }

}
