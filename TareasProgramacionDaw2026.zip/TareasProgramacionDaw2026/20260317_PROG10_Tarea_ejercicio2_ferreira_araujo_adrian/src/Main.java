import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.io.*;
import java.time.LocalDate;
import java.util.Scanner;
import PRO10_2_util.Validar;
// imports para que funcione

public class Main extends Application {

    // Lista que se sincroniza con la tabla
    private ObservableList<Vehiculo> listaVehiculos = FXCollections.observableArrayList();
    private TableView<Vehiculo> tabla = new TableView<>();
    private final String NOMBRE_FICHERO = "vehiculos.txt";

    @Override
    public void start(Stage primaryStage) {

        // CARGAR DATOS
        cargarDatosDesdeArchivo();

        // CONFIGURAR COLUMNAS
        TableColumn<Vehiculo, String> colMatricula = new TableColumn<>("Matrícula");
        colMatricula.setCellValueFactory(new PropertyValueFactory<>("matricula"));

        TableColumn<Vehiculo, String> colMarca = new TableColumn<>("Marca");
        colMarca.setCellValueFactory(new PropertyValueFactory<>("marca"));

        TableColumn<Vehiculo, Integer> colKms = new TableColumn<>("Kilómetros");
        colKms.setCellValueFactory(new PropertyValueFactory<>("Kms"));

        TableColumn<Vehiculo, Double> colPrecio = new TableColumn<>("Precio (€)");
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));

        tabla.getColumns().addAll(colMatricula, colMarca, colKms, colPrecio);
        tabla.setItems(listaVehiculos);
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // FORMULARIO DE ENTRADA
        GridPane formulario = new GridPane();
        formulario.setHgap(10); formulario.setVgap(10);
        formulario.setPadding(new Insets(10));


        TextField txtMarca = new TextField(); txtMarca.setPromptText("Marca");
        TextField txtMatricula = new TextField(); txtMatricula.setPromptText("1234BBB");
        TextField txtKms = new TextField(); txtKms.setPromptText("Kms totales");
        TextField txtPrecio = new TextField(); txtPrecio.setPromptText("Precio venta");
        TextField txtDni = new TextField(); txtDni.setPromptText("DNI Propietario");

        Button btnAdd = new Button("Registrar Vehículo");
        btnAdd.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-font-weight: bold;");

        formulario.add(new Label("Marca:"), 0, 0); formulario.add(txtMarca, 1, 0);
        formulario.add(new Label("Matrícula:"), 2, 0); formulario.add(txtMatricula, 3, 0);
        formulario.add(new Label("Kms:"), 0, 1); formulario.add(txtKms, 1, 1);
        formulario.add(new Label("Precio:"), 2, 1); formulario.add(txtPrecio, 3, 1);
        formulario.add(new Label("DNI:"), 0, 2); formulario.add(txtDni, 1, 2);
        formulario.add(btnAdd, 3, 2);
        // --- SECCIÓN DE BORRADO ---
        HBox seccionBorrar = new HBox(10);
        seccionBorrar.setPadding(new Insets(10));
        TextField txtBorrarMatricula = new TextField();
        txtBorrarMatricula.setPromptText("Matrícula a eliminar");
        Button btnBorrar = new Button("Borrar por Matrícula");
        btnBorrar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");

        seccionBorrar.getChildren().addAll(new Label("Eliminar:"), txtBorrarMatricula, btnBorrar);

        // LÓGICA DEL BOTÓN AÑADIR
        btnAdd.setOnAction(e -> {
            try {
                // Capturar datos de los campos
                String matricula = txtMatricula.getText().toUpperCase().trim();
                String marca = txtMarca.getText().trim();
                String dni = txtDni.getText().trim();

                // COMPROBACIÓN DE CAMPOS VACIOS
                if (matricula.isEmpty() || marca.isEmpty() || dni.isEmpty()) {
                    throw new Exception("Marca, Matrícula y DNI son campos obligatorios.");
                }

                // COMPROBACIÓN MATRICULA DUPLICADA
                // Recorremos la lista actual para ver si ya existe esa matrícula
                for (Vehiculo existente : listaVehiculos) {
                    if (existente.getMatricula().equalsIgnoreCase(matricula)) {
                        throw new Exception("Error: Ya existe un vehículo con la matrícula " + matricula);
                    }
                }

                // COMPROBACIÓN DEL FORMATO
                if (!Validar.validarFormatoMatricula(matricula)) {
                    throw new Exception("Formato de matrícula incorrecto. Debe ser: 1234BBB");
                }

                // COMPROBACIÓN DE DUPLICADOS
                for (Vehiculo v : listaVehiculos) {
                    if (v.getMatricula().equals(matricula)) {
                        throw new Exception("Error: El vehículo " + matricula + " ya está registrado.");
                    }
                }

                // COMPROBACIÓN DE DNI
                String dniValidado = Validar.validarDNI(dni);
                if (dniValidado.isEmpty()) {
                    throw new Exception("El DNI no cumple el formato (8 números y 1 letra).");
                }

                // COMPROBACION NUM POSITIVOS
                int kms = Integer.parseInt(txtKms.getText());
                double precio = Double.parseDouble(txtPrecio.getText());

                if (!Validar.esPositivo(kms) || precio <= 0) {
                    throw new Exception("Los Kms y el Precio deben ser números positivos.");
                }
                // Creamos el objeto Vehiculo
                Vehiculo nuevoVehiculo = new Vehiculo(
                        txtMarca.getText(),
                        txtMatricula.getText(),
                        Integer.parseInt(txtKms.getText()),
                        LocalDate.now(), // FECHA ACTUAL DEL MOMENTO EN EL QUE LO AÑADIMOS
                        "Vehículo gestionado desde JavaFX",
                        Double.parseDouble(txtPrecio.getText()),
                        "Propietario Genérico",
                        dniValidado
                );

                // Añadir a la lista visual
                listaVehiculos.add(nuevoVehiculo);

                // GUARDAR EN EL TXT
                guardarEnArchivo(nuevoVehiculo);

                // Limpiar campos
                txtMarca.clear(); txtMatricula.clear(); txtKms.clear(); txtPrecio.clear(); txtDni.clear();

            } catch (NumberFormatException nfe) {
                mostrarAlerta("Error de formato", "Kms y Precio deben ser números.");
            } catch (Exception ex) {
                mostrarAlerta("Error de validación", ex.getMessage());
            }
        });
        // BTN DE BORRADO
        btnBorrar.setOnAction(e -> {
            String matABorrar = txtBorrarMatricula.getText().toUpperCase().trim();
            boolean eliminado = listaVehiculos.removeIf(v -> v.getMatricula().equals(matABorrar));

            if (eliminado) {
                actualizarFicheroCompleto(); // Sobrescribe el txt sin el vehículo borrado
                txtBorrarMatricula.clear();
                mostrarInfo("Éxito", "Vehículo eliminado del sistema.");
            } else {
                mostrarAlerta("No encontrado", "No existe ningún vehículo con esa matrícula.");
            }
        });
        // --- DISEÑO FINAL ---
        VBox layout = new VBox(10, new Label("GESTIÓN DE VEHÍCULOS"), tabla, formulario, new Separator(), seccionBorrar);
        layout.setPadding(new Insets(20));

        primaryStage.setScene(new Scene(layout, 750, 600));
        primaryStage.setTitle("PROG10_Tarea_ejercicio2");
        primaryStage.show();
    }

    // --- PERSISTENCIA ---

    private void guardarEnArchivo(Vehiculo v) {
        try (PrintWriter out = new PrintWriter(new FileWriter(NOMBRE_FICHERO, true))) {
            out.println(v.getMatricula() + ";" + v.getMarca() + ";" + v.getKms() + ";" + v.getPrecio() + ";" + v.getDniPropietario());
        } catch (IOException e) { System.err.println("Error al guardar."); }
    }

    private void actualizarFicheroCompleto() {
        // Sobrescribimos (sin el 'true') para limpiar el archivo y volcar la lista actualizada
        try (PrintWriter out = new PrintWriter(new FileWriter(NOMBRE_FICHERO))) {
            for (Vehiculo v : listaVehiculos) {
                out.println(v.getMatricula() + ";" + v.getMarca() + ";" + v.getKms() + ";" + v.getPrecio() + ";" + v.getDniPropietario());
            }
        } catch (IOException e) { System.err.println("Error al actualizar."); }
    }

    // OBTENER LA INFO DESDE EL ARCHIVO
    private void cargarDatosDesdeArchivo() {
        File f = new File(NOMBRE_FICHERO);
        if (!f.exists()) return;
        try (Scanner sc = new Scanner(f)) {
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                if (linea.trim().isEmpty()) continue; // Ignora líneas vacías

                String[] d = linea.split(";");
                if (d.length >= 5) {
                    // USAMOS .trim() EN CADA CAMPO PARA LIMPIAR DATOS ANTIGUOS
                    String matricula = d[0].trim();
                    String marca = d[1].trim();
                    int kms = Integer.parseInt(d[2].trim());
                    double precio = Double.parseDouble(d[3].trim());
                    String dni = d[4].trim();

                    listaVehiculos.add(new Vehiculo(marca, matricula, kms, LocalDate.now(), "", precio, "", dni));
                }
            }
            //ERROR
        } catch (Exception e) {
            System.err.println("Error al cargar: " + e.getMessage());
        }
    }
// SALTA UN WARNING
    private void mostrarAlerta(String t, String m) {
        Alert a = new Alert(Alert.AlertType.WARNING); a.setTitle(t); a.setContentText(m); a.showAndWait();
    }
// MUESTRA INFO
    private void mostrarInfo(String t, String m) {
        Alert a = new Alert(Alert.AlertType.INFORMATION); a.setTitle(t); a.setContentText(m); a.showAndWait();
    }
// PARA QUE ARRANQUE
    public static void main(String[] args) { launch(args); }
}