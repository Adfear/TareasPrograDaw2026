package PROG05_Ejerc1_util;

import java.time.LocalDate;

/**
 *
 * @author Adrian Ferreira
 */

// clase validar para comprobaciones
public class   Validar {
// en esPositivo comprobamos que el numero sea valido y mayor que 0
    public static boolean esPositivo(int num) {
        boolean b = num > 0;
        if (b) return true;
        else {
            System.out.println("Numero inválido");
            return false;
        }
    }
// aqui comprobamos que la fecha sea mayor que el dia actual, si es mayor da fallo
    public static boolean fechaMayorHoy(LocalDate fechaMatriculacion){
        LocalDate hoy = LocalDate.now(); return hoy.isBefore(fechaMatriculacion);

    }

// aqui validamos el dni pero no me funciona con minusculas, no se porque
    public static String validarDNI(String dni) {
        if (dni.matches("\\d{8}[a-zA-Z]")) {
            String var1 = dni.substring(0, 8);
            return var1 + dni.substring(8).toUpperCase();
        } else {
            System.out.println("DNI inválido");
            return "";
        }
    }


}
