package PROG05_Ejerc1;

import java.time.LocalDate;
import java.time.Period;

/**
 *
 * @author Adrian Ferreira
 */

/* clase vehiculo y getters/setters

 */
public class Vehiculo{

    private String marca;
    private String matricula;
    private int Kms;
    private LocalDate fechaMatriculacion;
    private String descripcion;
    private double precio;
    private String propietario;
    private String dniPropietario;



    public Vehiculo(String marca, String matricula, int Kms, LocalDate fechaMatriculacion, String descripcion, double precio, String propietario, String dniPropietario) {
        this.marca = marca;
        this.matricula = matricula;
        this.Kms = Kms;
        this.fechaMatriculacion = fechaMatriculacion;
        this.descripcion = descripcion;
        this.precio = precio;
        this.propietario = propietario;
        this.dniPropietario = dniPropietario;
    }

    public String getMarca() { return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getKms() {
        return Kms;
    }

    public void setKms(int Kms) {
        this.Kms = Kms;
    }

    public LocalDate getFechaMatriculacion() {
        return fechaMatriculacion;
    }

    public void setFechaMatriculacion(LocalDate fechaMatriculacion) {
        this.fechaMatriculacion = fechaMatriculacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getpropietario() {
        return propietario;
    }

    public void setpropietario(String propietario) {
        this.propietario = propietario;
    }

    public String getDniPropietario() {
        return dniPropietario;
    }

    public void setDniPropietario(String dniPropietario) {
        this.dniPropietario = dniPropietario;
    }

    public int get_Anios(){
        LocalDate f1 = this.fechaMatriculacion;
        LocalDate f2 = LocalDate.now();

        Period p = Period.between(f1, f2);
        return p.getYears();
    }

    @Override
    public String toString() {
        return "Vehiculo{" +
                "marca='" + marca + '\'' +
                ", matricula='" + matricula + '\'' +
                ", numKM=" + Kms +
                ", fechaMatriculación=" + fechaMatriculacion +
                ", descripcion='" + descripcion + '\'' +
                ", precio=" + precio +
                ", nombrePropietario='" + propietario + '\'' +
                ", dniPropietario='" + dniPropietario + '\'' +
                '}';
    }
}