package PROG05_Ejerc1;


import PROG05_Ejerc1_util.Validar;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Scanner;


/**
 *
 * @author Adrian Ferreira
 */

public class Principal {
//scanner para recibir datos
    public static void main(String[] args) {
    Scanner sn = new Scanner(System.in);
    sn.useDelimiter("\n");
    sn.useLocale(Locale.US);

    boolean salir = false;
    int opcion;
    Vehiculo v = null;

    String marca, matricula, descripcion, nombreProp, dniProp;
    int km, dia, mes, anio;
    double precio;
    LocalDate fechaMatriculacion;
//menú
    while (!salir) {

        try {
            System.out.println("---- Sistema de gestion de vehiculos ----");

            System.out.println("1. Nuevo vehiculo");
            System.out.println("2. Ver matricula");
            System.out.println("3. Ver Kms");
            System.out.println("4. Actualizar Kms");
            System.out.println("5. Ver antigüedad");
            System.out.println("6. Ver propietario");
            System.out.println("7. Ver descripción");
            System.out.println("8. Ver precio");
            System.out.println("9. Salir");
            System.out.println("---- Elige una opción: ----");

// para que introduzca un numero si o si y no cualquier cosa
            if (!sn.hasNextInt()) {
                System.out.println(" Debes introducir un num entero ");
                sn.next(); // Limpiamos el búfer
                continue; // Volvemos al inicio del menú
            }

            opcion = sn.nextInt();
            sn.nextLine(); // Limpiar el salto de línea después de nextInt()
// switch para elegir en las opciones
            switch (opcion) {
                case 1:
                    System.out.println("* Introduce marca:");
                    marca = sn.next();

                    System.out.println("* Introduce matricula:");
                    matricula = sn.next();

                    // está abajo de todo, sirve para que los datos introducidos sean correctos
                    km = leerEnteroSeguro(sn,"* Introduce el número de Kms:");
                    dia = leerEnteroSeguro(sn, "* Introduce el día de matriculación:");
                    mes = leerEnteroSeguro(sn, "* Introduce el mes:");
                    anio = leerEnteroSeguro(sn, "* Introduce el año:");
                    fechaMatriculacion = LocalDate.of(anio, mes, dia);

                    if (Validar.fechaMayorHoy(fechaMatriculacion)) {
                        throw new Exception("* La fecha de matriculación no puede ser posterior al día actual");
                    }

                    System.out.println("* Introduce la descripción");
                    descripcion = sn.next();
                    System.out.println("* Introduce el nombre del propietario");
                    nombreProp = sn.next();
                    System.out.println("* Introduce el DNI del propietario");
                    dniProp = sn.next();



                    for(dniProp = sn.nextLine(); Validar.validarDNI(dniProp).equals(""); dniProp = sn.nextLine()) {
                        System.out.println("DNI incorrecto. Introduce tu DNI:");
                    }

                    System.out.println("* Introduce el precio");
                    precio = sn.nextDouble();
                    if (precio < 0) {
                        throw new IllegalArgumentException("* El precio debe ser positivo, no me creo que sea tan barato");
                    }

                    v = new Vehiculo(marca, matricula, km, fechaMatriculacion, descripcion, precio, nombreProp, dniProp);
                    System.out.println("*** Vehiculo creado ***");

                    break;
                case 2:
                    if (v != null) {
                        System.out.println("* Matricula: " + v.getMatricula());
                    } else {
                        System.out.println("* Debes crear un vehiculo.");
                    }
                    break;
                case 3:
                    if (v != null) {
                        System.out.println("* Kilometros: " + v.getKms());
                    } else {
                        System.out.println("* Debes crear un vehiculo.");
                    }
                    break;




                case 4:
                    if (v != null) {
                        boolean kmValido = false;
                        while (!kmValido) {
                            System.out.println("* Introduce los nuevos kilómetros (deben ser mayores a " + v.getKms() + "):");

                            if (sn.hasNextInt()) {
                                int nuevosKm = sn.nextInt();

                                //  que sea positivo Y mayor o igual al actual
                                if (Validar.esPositivo(nuevosKm) && nuevosKm >= v.getKms()) {
                                    v.setKms(nuevosKm);
                                    System.out.println(" Kilómetros actualizados ");
                                    kmValido = true;
                                } else {
                                    System.out.println("No puedes introducir menos kilómetros de los que ya tiene (" + v.getKms() + ").");
                                }
                            } else {
                                System.out.println(" Introduce un número entero válido.");
                                sn.next();
                            }
                        }
                    } else {
                        System.out.println("Debes crear un vehículo primero");
                    }
                    break;
                case 5:
                    if (v != null) {
                        System.out.println("* Antigüedad: " + v.get_Anios() + " años");
                    } else {
                        System.out.println("* Debes crear un vehiculo");
                    }
                    break;
                case 6:
                    if (v != null) {
                        System.out.println("* Propietario: " + v.getpropietario() + " " + v.getDniPropietario());
                    } else {
                        System.out.println("* Debes crear un vehiculo");
                    }
                    break;
                case 7:
                    if (v != null) {
                        System.out.println("* Descripción: " + v.getDescripcion());
                        System.out.println("* Matricula: " + v.getMatricula());
                        System.out.println("* Kilometros: " + v.getKms());
                    } else {
                        System.out.println(" Debes crear un vehiculo");
                    }
                    break;
                case 8:
                    if (v != null) {
                        System.out.println("Precio: " + v.getPrecio());
                    } else {
                        System.out.println("Debes crear un vehiculo");
                    }
                    break;
                case 9:
                    salir = true;
                    break;
                default:
                    System.out.println("*** Elige una opción entre 1 y 9 ***");


            }
        } catch (Exception e) {
            System.out.println("***  ERROR... ***");
            sn.nextLine(); // Limpieza del búfer para evitar bucle infinito


        }

    }
        sn.close();
}

// para que lo introducido sea correcto
    private static int leerEnteroSeguro(Scanner sn, String mensaje) {
        int numero = -1;
        boolean esValido = false;
        while (!esValido) {
            System.out.println(mensaje);
            if (sn.hasNextInt()) {
                numero = sn.nextInt();
                if (Validar.esPositivo(numero)) {
                    esValido = true;
                } else {
                    System.out.println(" El num debe ser positivo.");
                }
            } else {
                System.out.println("Introduce solo numero");
                sn.next();
            }
        }
        return numero;
    }
}